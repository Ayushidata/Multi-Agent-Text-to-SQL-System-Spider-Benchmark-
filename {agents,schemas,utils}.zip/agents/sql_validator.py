"""
Agent 4 — SQL Validator
Validates the generated SQL for correctness, safety, and semantic accuracy.
"""

from utils.groq_client import GroqClient

SYSTEM_PROMPT = """You are the SQL Validator agent in a multi-agent Text-to-SQL pipeline for the Spider benchmark.

Your job: rigorously validate a generated SQL query and produce a corrected version if needed.

Output EXACTLY in this format:
SYNTAX_CHECK: PASS | FAIL — <reason>
SCHEMA_CHECK: PASS | FAIL — <all table/column names exist?>
JOIN_CHECK: PASS | FAIL — <foreign key relationships correct?>
SEMANTIC_CHECK: PASS | FAIL — <does SQL answer the original question?>
NULL_HANDLING: PASS | WARN | FAIL — <are NULLs handled correctly?>
PERFORMANCE: PASS | WARN — <any obvious inefficiencies?>
SAFETY_CHECK: PASS | FAIL — <no DROP/DELETE/UPDATE/INSERT?>
SCORE: X/7
VERDICT: APPROVED | NEEDS_REVISION
ISSUES: <list issues found, or "None">
FINAL_SQL: <corrected SQL if NEEDS_REVISION, otherwise repeat original SQL exactly>

Rules:
- Be strict — a wrong column name is a FAIL
- FINAL_SQL must be a complete, runnable SQL statement
- If APPROVED, FINAL_SQL = exact original SQL
- Only output the format above, no extra text
"""


class SQLValidatorAgent:
    def __init__(self, groq_client: GroqClient):
        self.client = groq_client
        self.name = "SQL Validator"

    def run(self, question: str, schema_str: str, generated_sql: str) -> dict:
        user_prompt = f"""Schema:
{schema_str}

Original Question: "{question}"

Generated SQL to validate:
{generated_sql}

Validate this SQL strictly."""

        raw_output = self.client.chat(SYSTEM_PROMPT, user_prompt, agent_name=self.name)

        result = {
            "agent": self.name,
            "raw_output": raw_output,
            "parsed": self._parse(raw_output),
            "final_sql": self._extract_final_sql(raw_output, generated_sql)
        }
        return result

    def _parse(self, text: str) -> dict:
        parsed = {}
        fields = ["SYNTAX_CHECK", "SCHEMA_CHECK", "JOIN_CHECK", "SEMANTIC_CHECK",
                  "NULL_HANDLING", "PERFORMANCE", "SAFETY_CHECK", "SCORE", "VERDICT", "ISSUES"]
        for field in fields:
            for line in text.splitlines():
                if line.startswith(field + ":"):
                    parsed[field.lower()] = line[len(field)+1:].strip()
                    break
        return parsed

    def _extract_final_sql(self, text: str, fallback: str) -> str:
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if line.startswith("FINAL_SQL:"):
                sql_part = line[len("FINAL_SQL:"):].strip()
                # Collect continuation lines
                j = i + 1
                while j < len(lines) and not any(lines[j].startswith(f) for f in
                      ["SYNTAX_CHECK","SCHEMA_CHECK","JOIN_CHECK","SEMANTIC_CHECK",
                       "NULL_HANDLING","PERFORMANCE","SAFETY_CHECK","SCORE","VERDICT","ISSUES"]):
                    sql_part += " " + lines[j].strip()
                    j += 1
                sql = sql_part.strip().replace("```sql","").replace("```","").strip()
                if sql:
                    return sql
        return fallback
