"""
Agent 1 — Query Planner
Analyzes natural language query and produces a structured execution plan.
"""

from utils.groq_client import GroqClient

SYSTEM_PROMPT = """You are the Query Planner agent in a multi-agent Text-to-SQL pipeline for the Spider benchmark.

Your job: analyze a natural language question and produce a structured query plan.

Output EXACTLY in this format:
INTENT: <one sentence — what the user wants>
ENTITIES: <key tables and columns needed, comma separated>
OPERATIONS: <SQL operations needed: SELECT / JOIN / WHERE / GROUP BY / ORDER BY / HAVING / SUBQUERY / AGGREGATE>
COMPLEXITY: <Simple | Medium | Complex>
AMBIGUITIES: <any unclear aspects, or "None">
REASONING: <brief explanation of your decomposition>

Rules:
- Be concise and precise
- Do NOT write any SQL yet
- Only reference tables/columns that exist in the provided schema
- If the question is ambiguous, flag it in AMBIGUITIES
"""


class QueryPlannerAgent:
    def __init__(self, groq_client: GroqClient):
        self.client = groq_client
        self.name = "Query Planner"

    def run(self, question: str, schema_str: str) -> dict:
        user_prompt = f"""Schema:
{schema_str}

Natural Language Question: "{question}"

Produce the query plan."""

        raw_output = self.client.chat(SYSTEM_PROMPT, user_prompt, agent_name=self.name)

        result = {
            "agent": self.name,
            "question": question,
            "raw_output": raw_output,
            "parsed": self._parse(raw_output)
        }
        return result

    def _parse(self, text: str) -> dict:
        parsed = {}
        for field in ["INTENT", "ENTITIES", "OPERATIONS", "COMPLEXITY", "AMBIGUITIES", "REASONING"]:
            for line in text.splitlines():
                if line.startswith(field + ":"):
                    parsed[field.lower()] = line[len(field)+1:].strip()
                    break
        return parsed
