"""
Agent 2 — Schema Reasoner
Given the query plan, identifies exact tables, columns, joins, and conditions.
"""

from utils.groq_client import GroqClient

SYSTEM_PROMPT = """You are the Schema Reasoner agent in a multi-agent Text-to-SQL pipeline for the Spider benchmark.

Your job: given a query plan, reason over the database schema to identify exact tables, columns, and relationships needed.

Output EXACTLY in this format:
TABLES: <comma-separated list of tables needed with brief justification>
SELECT_COLUMNS: <exact column names for SELECT clause>
JOIN_CONDITIONS: <table1.col = table2.col pairs, or "None">
WHERE_CONDITIONS: <filter conditions, or "None">
GROUP_BY: <columns to group by, or "None">
ORDER_BY: <columns to sort by, or "None">
AGGREGATIONS: <COUNT/SUM/AVG/MAX/MIN expressions, or "None">
SUBQUERY_NEEDED: <Yes / No — with reason>
NOTES: <any important schema constraints or edge cases>

Rules:
- Use EXACT column names from the schema (case-sensitive)
- Reference foreign keys for JOIN conditions
- Do NOT write SQL yet
"""


class SchemaReasonerAgent:
    def __init__(self, groq_client: GroqClient):
        self.client = groq_client
        self.name = "Schema Reasoner"

    def run(self, question: str, schema_str: str, planner_output: dict) -> dict:
        user_prompt = f"""Schema:
{schema_str}

Original Question: "{question}"

Query Plan from Planner Agent:
{planner_output['raw_output']}

Now perform deep schema reasoning to identify exact tables, columns, and conditions needed."""

        raw_output = self.client.chat(SYSTEM_PROMPT, user_prompt, agent_name=self.name)

        result = {
            "agent": self.name,
            "raw_output": raw_output,
            "parsed": self._parse(raw_output)
        }
        return result

    def _parse(self, text: str) -> dict:
        parsed = {}
        fields = ["TABLES", "SELECT_COLUMNS", "JOIN_CONDITIONS", "WHERE_CONDITIONS",
                  "GROUP_BY", "ORDER_BY", "AGGREGATIONS", "SUBQUERY_NEEDED", "NOTES"]
        for field in fields:
            for line in text.splitlines():
                if line.startswith(field + ":"):
                    parsed[field.lower()] = line[len(field)+1:].strip()
                    break
        return parsed
