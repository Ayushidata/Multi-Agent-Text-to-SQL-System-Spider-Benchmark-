"""
Agent 3 — SQL Generator
Synthesizes the final SQL query from the plan and schema analysis.
"""

from utils.groq_client import GroqClient

SYSTEM_PROMPT = """You are the SQL Generator agent in a multi-agent Text-to-SQL pipeline for the Spider benchmark.

Your job: write a correct, optimized SQL query using the query plan and schema analysis from previous agents.

Rules:
- Use EXACT table and column names from the schema
- Use table aliases (T1, T2, ...) for clarity in JOINs
- Prefer explicit JOINs over implicit (comma-separated) joins
- Use proper aggregate functions when needed
- Handle potential NULLs with IS NULL / IS NOT NULL where appropriate
- For Spider benchmark: use SQLite-compatible syntax
- Output ONLY the SQL query — no explanation, no markdown fences, no comments
- Start directly with SELECT (or WITH for CTEs)

Examples of good output:
  SELECT count(*) FROM singer
  SELECT T1.name, T2.capacity FROM concert T1 JOIN stadium T2 ON T1.stadium_id = T2.stadium_id
"""


class SQLGeneratorAgent:
    def __init__(self, groq_client: GroqClient):
        self.client = groq_client
        self.name = "SQL Generator"

    def run(self, question: str, schema_str: str, planner_output: dict, schema_output: dict) -> dict:
        user_prompt = f"""Schema:
{schema_str}

Original Question: "{question}"

Query Plan (Agent 1):
{planner_output['raw_output']}

Schema Analysis (Agent 2):
{schema_output['raw_output']}

Generate the SQL query now. Output ONLY the SQL, nothing else."""

        raw_output = self.client.chat(SYSTEM_PROMPT, user_prompt, agent_name=self.name)

        # Clean up common LLM artifacts
        sql = raw_output.strip()
        for fence in ["```sql", "```SQL", "```"]:
            sql = sql.replace(fence, "")
        sql = sql.strip()

        result = {
            "agent": self.name,
            "raw_output": raw_output,
            "sql": sql
        }
        return result
