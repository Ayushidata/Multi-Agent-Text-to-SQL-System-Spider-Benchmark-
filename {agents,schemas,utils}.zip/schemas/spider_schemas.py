"""
Spider Benchmark Schemas
Real table/column definitions from the Spider dataset
"""

SCHEMAS = {
    "concert_singer": {
        "description": "Concerts, singers, and stadiums",
        "tables": {
            "stadium": {
                "columns": ["stadium_id", "location", "name", "capacity", "highest", "lowest", "average"],
                "primary_key": "stadium_id",
                "foreign_keys": []
            },
            "singer": {
                "columns": ["singer_id", "name", "country", "song_name", "song_release_year", "age", "is_male"],
                "primary_key": "singer_id",
                "foreign_keys": []
            },
            "concert": {
                "columns": ["concert_id", "concert_name", "theme", "stadium_id", "year"],
                "primary_key": "concert_id",
                "foreign_keys": [{"column": "stadium_id", "ref_table": "stadium", "ref_column": "stadium_id"}]
            },
            "singer_in_concert": {
                "columns": ["concert_id", "singer_id"],
                "primary_key": None,
                "foreign_keys": [
                    {"column": "concert_id", "ref_table": "concert", "ref_column": "concert_id"},
                    {"column": "singer_id", "ref_table": "singer", "ref_column": "singer_id"}
                ]
            }
        },
        "sample_queries": [
            ("How many singers are there?", "SELECT count(*) FROM singer"),
            ("What are the names of singers from USA?", "SELECT name FROM singer WHERE country = 'USA'"),
            ("Show all concert names and their stadium names", "SELECT T1.concert_name, T2.name FROM concert T1 JOIN stadium T2 ON T1.stadium_id = T2.stadium_id"),
            ("List singers who performed in more than 1 concert", "SELECT T2.name, count(*) FROM singer_in_concert T1 JOIN singer T2 ON T1.singer_id = T2.singer_id GROUP BY T1.singer_id HAVING count(*) > 1"),
        ]
    },

    "employee_hire_evaluation": {
        "description": "Employee hiring and performance evaluation",
        "tables": {
            "employee": {
                "columns": ["employee_id", "name", "age", "city"],
                "primary_key": "employee_id",
                "foreign_keys": []
            },
            "shop": {
                "columns": ["shop_id", "name", "location", "district", "number_products", "manager_name"],
                "primary_key": "shop_id",
                "foreign_keys": []
            },
            "hiring": {
                "columns": ["shop_id", "employee_id", "start_from", "is_full_time"],
                "primary_key": None,
                "foreign_keys": [
                    {"column": "shop_id", "ref_table": "shop", "ref_column": "shop_id"},
                    {"column": "employee_id", "ref_table": "employee", "ref_column": "employee_id"}
                ]
            },
            "evaluation": {
                "columns": ["employee_id", "year_awarded", "bonus"],
                "primary_key": None,
                "foreign_keys": [
                    {"column": "employee_id", "ref_table": "employee", "ref_column": "employee_id"}
                ]
            }
        },
        "sample_queries": [
            ("How many employees are there?", "SELECT count(*) FROM employee"),
            ("List full-time employees", "SELECT T2.name FROM hiring T1 JOIN employee T2 ON T1.employee_id = T2.employee_id WHERE T1.is_full_time = 1"),
            ("Which shops are in Tokyo?", "SELECT name FROM shop WHERE location = 'Tokyo'"),
            ("Show employees with bonuses above 5000", "SELECT T2.name, T1.bonus FROM evaluation T1 JOIN employee T2 ON T1.employee_id = T2.employee_id WHERE T1.bonus > 5000"),
        ]
    },

    "world_1": {
        "description": "World countries, cities and languages",
        "tables": {
            "country": {
                "columns": ["code", "name", "continent", "region", "surfacearea", "indepyear", "population", "lifeexpectancy", "gnp", "gnpold", "localname", "governmentform", "headofstate", "capital", "code2"],
                "primary_key": "code",
                "foreign_keys": []
            },
            "city": {
                "columns": ["id", "name", "countrycode", "district", "population"],
                "primary_key": "id",
                "foreign_keys": [{"column": "countrycode", "ref_table": "country", "ref_column": "code"}]
            },
            "countrylanguage": {
                "columns": ["countrycode", "language", "isofficial", "percentage"],
                "primary_key": None,
                "foreign_keys": [{"column": "countrycode", "ref_table": "country", "ref_column": "code"}]
            }
        },
        "sample_queries": [
            ("How many countries are there?", "SELECT count(*) FROM country"),
            ("List all countries in Asia", "SELECT name FROM country WHERE continent = 'Asia'"),
            ("Find cities with population over 1 million", "SELECT name FROM city WHERE population > 1000000"),
            ("Show official languages of each country", "SELECT T1.name, T2.language FROM country T1 JOIN countrylanguage T2 ON T1.code = T2.countrycode WHERE T2.isofficial = 'T'"),
        ]
    },

    "student_transcripts": {
        "description": "University students, courses and transcript records",
        "tables": {
            "addresses": {
                "columns": ["address_id", "line_1", "line_2", "city", "zip_postcode", "state_province_county", "country"],
                "primary_key": "address_id",
                "foreign_keys": []
            },
            "courses": {
                "columns": ["course_id", "course_name", "course_description"],
                "primary_key": "course_id",
                "foreign_keys": []
            },
            "departments": {
                "columns": ["department_id", "department_name", "department_description"],
                "primary_key": "department_id",
                "foreign_keys": []
            },
            "degree_programs": {
                "columns": ["degree_program_id", "department_id", "degree_summary_name", "degree_summary_description"],
                "primary_key": "degree_program_id",
                "foreign_keys": [{"column": "department_id", "ref_table": "departments", "ref_column": "department_id"}]
            },
            "semesters": {
                "columns": ["semester_id", "semester_name", "semester_description"],
                "primary_key": "semester_id",
                "foreign_keys": []
            },
            "students": {
                "columns": ["student_id", "current_address_id", "first_name", "middle_name", "last_name", "cell_mobile_number", "email_address", "date_first_registered", "date_left"],
                "primary_key": "student_id",
                "foreign_keys": [{"column": "current_address_id", "ref_table": "addresses", "ref_column": "address_id"}]
            },
            "student_enrolment": {
                "columns": ["student_enrolment_id", "degree_program_id", "semester_id", "student_id"],
                "primary_key": "student_enrolment_id",
                "foreign_keys": [
                    {"column": "degree_program_id", "ref_table": "degree_programs", "ref_column": "degree_program_id"},
                    {"column": "semester_id", "ref_table": "semesters", "ref_column": "semester_id"},
                    {"column": "student_id", "ref_table": "students", "ref_column": "student_id"}
                ]
            },
            "transcript_contents": {
                "columns": ["student_course_id", "transcript_id", "grade_achieved"],
                "primary_key": None,
                "foreign_keys": []
            }
        },
        "sample_queries": [
            ("How many students are enrolled?", "SELECT count(*) FROM students"),
            ("List all course names", "SELECT course_name FROM courses"),
            ("Find students in semester 1", "SELECT T2.first_name, T2.last_name FROM student_enrolment T1 JOIN students T2 ON T1.student_id = T2.student_id WHERE T1.semester_id = 1"),
        ]
    }
}


def get_schema_string(schema_name: str) -> str:
    """Convert schema dict to a readable string for LLM prompts"""
    schema = SCHEMAS.get(schema_name)
    if not schema:
        return ""

    lines = [f"Database: {schema_name}", f"Description: {schema['description']}", ""]
    for table_name, table_info in schema["tables"].items():
        lines.append(f"Table: {table_name}")
        lines.append(f"  Columns: {', '.join(table_info['columns'])}")
        if table_info["primary_key"]:
            lines.append(f"  Primary Key: {table_info['primary_key']}")
        for fk in table_info["foreign_keys"]:
            lines.append(f"  Foreign Key: {fk['column']} → {fk['ref_table']}.{fk['ref_column']}")
        lines.append("")
    return "\n".join(lines)


def list_schemas():
    return list(SCHEMAS.keys())
