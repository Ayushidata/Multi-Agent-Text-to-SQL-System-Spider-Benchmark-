"""
Groq API Client Wrapper
Handles all LLM calls using Groq's ultra-fast inference
"""

import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()


class GroqClient:
    def __init__(self):
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key or api_key == "your_groq_api_key_here":
            raise ValueError(
                "GROQ_API_KEY not set!\n"
                "1. Get your key from https://console.groq.com\n"
                "2. Set it in .env file: GROQ_API_KEY=gsk_..."
            )
        self.client = Groq(api_key=api_key)
        self.model = os.getenv("GROQ_MODEL", "llama3-70b-8192")
        self.max_tokens = int(os.getenv("MAX_TOKENS", "1024"))
        self.temperature = float(os.getenv("TEMPERATURE", "0.1"))

    def chat(self, system_prompt: str, user_prompt: str, agent_name: str = "") -> str:
        """Single LLM call — returns response text"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
        )
        return response.choices[0].message.content.strip()
